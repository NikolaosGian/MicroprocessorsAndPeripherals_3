#include "DTH11.h"
#include <platform.h>
#include "gpio.h"
#include "delay.h"

#define PIN PA_10

void DHT11_Start(void){
	// Start pin transfer data
	gpio_set_mode(PIN, Output); 	// Set PA_10 as output
	gpio_set(PIN,0);  						// PA_10 set low (see manual DTH11)
	delay_ms(18);								// wait for 18 ms
	gpio_set(PIN,1);							// PA_10 set high (see manual DTH11)
	delay_us(20);								// wait for 20 us
	gpio_set_mode(PIN, Input);		// Start receiving
}

uint8_t DHT11_check_response(void){
	uint8_t response = 0;
	delay_us(40);												// Wait for DHT response middle signal
	if(!(gpio_get(PIN))){
		delay_us(80);											// DHT middle Pull up 
		if((gpio_get(PIN))) response = 1;	// if the pin is high, response is ok
		else response = 0;								// if response == 0 is false response
	}
	while(gpio_get(PIN));
	return response;
}


uint8_t DHT11_Read(void){
	uint8_t i,j;
	for (j = 0; j < 8; j++){
		while(!(gpio_get(PIN))); // wait for the pin to go high
		delay_us(28);						// wait for 28 us
		if(!(gpio_get(PIN))){		// if the pin is low
			i&=~(1<<(7-j));				// write 0
		}else i |= (1<<(7-j));	// if the pin is high, write 1
		while((gpio_get(PIN)));	// wait for the pin to go low
	}
	return i;
}
