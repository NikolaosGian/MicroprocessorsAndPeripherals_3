#ifndef DTH11_H
#define DTH11_H

#include <platform.h>
#include "gpio.h"
#include "delay.h"




void DHT11_Start(void);
	
uint8_t DHT11_check_response(void);

uint8_t DHT11_Read(void);

#endif // DTH11_H
