#include <platform.h>
#include <timer.h>
#include <stdio.h>
#include <string.h>
#include <gpio.h>
#include <uart.h>

#include "leds.h"
#include "DTH11.h"


#define AEM1 11										// 9629 -> 2+9 = 11
#define AEM2 9										//  9836 - > 3+6 = 9

float temp = -100.0;							// tempure 
int sRate = 0 , counter = 0; 		// Sampling Rate propably global to chenaghe it when switch press it



void switch_init(void){
	//#define P_SW PC13
	gpio_set_mode(P_SW, PullUp); // 1 switch
	
}

int switch_get(Pin pin){
	return !gpio_get(pin); // active low
}

uint8_t RH_byte1 , RH_byt2, Temp_byte1, Temp_byte2, SUM, presence;

char charTemp[64];
char charSRate[30];

void timer_ISR(void){
	DHT11_Start();
	presence = DHT11_check_response(); // if (presensce == 1 ) continue
	if (presence != 1){
		printf("Error");
	} 
	RH_byte1 = DHT11_Read();
	RH_byt2 = DHT11_Read();
	Temp_byte1 = DHT11_Read();
	Temp_byte2 = DHT11_Read();
	SUM = DHT11_Read();
	
	temp = (float) Temp_byte1; // getting float value of temp
	

	
	
	sprintf(charTemp,"%f", temp);
	sprintf(charSRate,"%d", sRate);
	
	uart_print("Temp= ");
	uart_print(charTemp);
	uart_print("\r\n");
	
	uart_print("Sample Rate= ");
	uart_print(charSRate);
	uart_print("\r\n");
}

int boolFist = 0;
int boolZhgos = 0;
int boolMonos = 0;

void firstTime(){
	if(boolFist == 1){
		timer_disable();
		delay_ms(AEM2 * 1000);
		//delay_ms(AEM1 * 1000);
		boolFist = 0;
		timer_enable();
	}
	//sRate = AEM1;
	sRate = AEM2;
}

void zhgos_ISR(){
	if(boolZhgos == 1){
		timer_disable();
		delay_ms(4 * 10000);
		boolZhgos = 0;
		timer_enable();
	}
	sRate = 4 ;// set new rate
}

void monos_ISR(){
	if ( boolMonos == 1){
		timer_disable();
		delay_ms(3 * 10000);
		boolMonos = 0;
		timer_enable();
	}
	sRate = 3; // set new rate.
}

void OnPressButton_isr(){
	counter++;
	if (counter == 1){boolFist = 1; firstTime();}
	if((counter%2) == 0){boolZhgos = 1; zhgos_ISR();}
	if((counter%3) ==0) {boolMonos = 1; monos_ISR();}
}

int main(){
	 
	uart_init(9600);										// Baud -> 9600
	uart_enable();
	

	leds_init();
	switch_init();
	gpio_set_trigger(P_SW, Rising);
	gpio_set_callback(P_SW, OnPressButton_isr);
	
	sRate = 1;
	timer_init(1000000); //  set period for 1 seconds
	
	timer_set_callback(timer_ISR); // sets timer_ISR to get the tempure from sensor
	
	timer_enable();
	__enable_irq();
	
	while(1){
			
		if(temp < 20.0){
			leds_set(0,0,1); // set the leds to blue
		}else if( temp > 25.0){
			leds_set(1,0,0); // set the leds to red
		}else{
			leds_set(0,1,0); // set the leds to green
		}
	}	
}
